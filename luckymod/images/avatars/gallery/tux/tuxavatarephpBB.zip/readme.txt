######################################
             TUXAvatare
######################################
Beschreibung:	151 Avatare des beliebten
		Linux-Symbols ;)

Author:		Pascal Langer
URL:		http://www.webmaster.cx/?file=tuxavatare
Datum:		05. Januar 2005
F�r:		phpBB

######################################

Installation:

1)	Die Avatare die sich unter /images/avatars/gallery/TUX dieses Archives befinden, bitte auch in /images/avatars/gallery/TUX hochladen.
	Das wars, unter Avatargallerie gibts nun eine Gallerie Namens TUX, wo sich die Avatare befinden.

Viel Spa� damit :)
######################################